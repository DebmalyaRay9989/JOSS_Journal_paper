# Archive identifiers supplied by author

Studio (primary numerical software):

```markdown
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.24528136.svg)](https://doi.org/10.5281/zenodo.24528136)
```

Agentic RAG (companion):

```markdown
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.24528059.svg)](https://doi.org/10.5281/zenodo.24528059)
```

Before publishing these badges, verify that each resolves to the intended archive, determine whether the identifier is version-specific or concept-level, and compare archive metadata and files with the actual release. For the primary review target, ensure the archived source includes the two non-numerical fixes and record the tested commit. A DOI is not evidence of numerical parity or six months of public development. Use the final reviewed version DOI at the conclusion of JOSS review.
