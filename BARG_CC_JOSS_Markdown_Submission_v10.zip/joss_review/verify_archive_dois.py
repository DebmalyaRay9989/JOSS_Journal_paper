"""Read-only metadata retrieval. Does not infer equivalence or approve a deposit."""
import json, urllib.request, urllib.error, datetime, sys
from pathlib import Path
DOIS={'studio':'10.5281/zenodo.24528136','rag':'10.5281/zenodo.24528059'}
def get(url):
    req=urllib.request.Request(url,headers={'Accept':'application/json','User-Agent':'BARG-CC archive verification/1.0'})
    with urllib.request.urlopen(req,timeout=15) as response:
        return json.load(response)
def collect():
    report={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':{},'scope':'Metadata only. Manual archive contents, release tag, source commit, license and rights review required.'}
    for role,doi in DOIS.items():
        record={'supplied_doi':doi}
        try:
            z=get('https://zenodo.org/api/records/'+doi.rsplit('.',1)[1]); m=z['metadata']
            record['zenodo']={'doi':z.get('doi'),'conceptdoi':z.get('conceptdoi'),'doi_matches':z.get('doi','').lower()==doi.lower(),'distinct_from_concept':bool(z.get('conceptdoi')) and z.get('conceptdoi')!=z.get('doi'),'title':m.get('title'),'creators':m.get('creators'),'version':m.get('version'),'license':m.get('license'),'publication_date':m.get('publication_date'),'resource_type':m.get('resource_type'),'related_identifiers':m.get('related_identifiers'),'files':[{k:f.get(k) for k in ('key','size','checksum','links')} for f in z.get('files',[])]}
        except Exception as e: record['zenodo_error']=str(e)
        try:
            a=get('https://api.datacite.org/dois/'+doi)['data']['attributes']; record['datacite']={k:a.get(k) for k in ('doi','titles','creators','version','types','rightsList','relatedIdentifiers','url','state','publicationYear')}
        except Exception as e: record['datacite_error']=str(e)
        report['records'][role]=record
    return report
if __name__=='__main__':
    r=collect(); dest=Path('archive-doi-evidence.json'); dest.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n',encoding='utf-8'); print(dest.resolve()); sys.exit(0 if all('zenodo' in x and 'datacite' in x for x in r['records'].values()) else 1)
